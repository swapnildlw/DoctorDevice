package com.stackroute.ServiceCenterService.service;

import com.stackroute.ServiceCenterService.model.User;

public interface ServiceCenterServiceI {
    User saveUser(User user);
}
